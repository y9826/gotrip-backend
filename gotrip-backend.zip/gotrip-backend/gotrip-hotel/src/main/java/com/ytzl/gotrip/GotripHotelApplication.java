package com.ytzl.gotrip;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GotripHotelApplication {

    public static void main(String[] args) {
        SpringApplication.run(GotripHotelApplication.class, args);
    }

}
