package com.ytzl.gotrip;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GotripOrderApplication {

    public static void main(String[] args) {
        SpringApplication.run(GotripOrderApplication.class, args);
    }

}
