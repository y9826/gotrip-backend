package com.ytzl.gotrip.model;
import java.io.Serializable;
import java.util.Date;
import java.math.BigDecimal;
/***
*   
*/
public class GotripHotelFeature implements Serializable {
        //
        private Long id;
        //
        private Long hotelId;
        //
        private Long featureId;
        //
        private Date creationDate;
        //
        private Long createdBy;
        //
        private Date modifyDate;
        //
        private Long modifiedBy;


        //get set 方法
        public void setId(Long  id){
            this.id=id;
        }
        public  Long getId(){
            return this.id;
        }
        public void setHotelId(Long  hotelId){
            this.hotelId=hotelId;
        }
        public  Long getHotelId(){
            return this.hotelId;
        }
        public void setFeatureId(Long  featureId){
            this.featureId=featureId;
        }
        public  Long getFeatureId(){
            return this.featureId;
        }
        public void setCreationDate(Date  creationDate){
            this.creationDate=creationDate;
        }
        public  Date getCreationDate(){
            return this.creationDate;
        }
        public void setCreatedBy(Long  createdBy){
            this.createdBy=createdBy;
        }
        public  Long getCreatedBy(){
            return this.createdBy;
        }
        public void setModifyDate(Date  modifyDate){
            this.modifyDate=modifyDate;
        }
        public  Date getModifyDate(){
            return this.modifyDate;
        }
        public void setModifiedBy(Long  modifiedBy){
            this.modifiedBy=modifiedBy;
        }
        public  Long getModifiedBy(){
            return this.modifiedBy;
        }
}
