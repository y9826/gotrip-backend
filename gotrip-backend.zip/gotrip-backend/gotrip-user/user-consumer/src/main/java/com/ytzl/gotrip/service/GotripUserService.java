package com.ytzl.gotrip.service;

import com.ytzl.gotrip.model.GotripUser;

public interface GotripUserService {

    /**
     * 根据用户登陆账号查询用户信息
     *
     * @param userCode 登陆账号
     * @return 用户信息（包含密码）
     */
    public GotripUser findByUserCode(String userCode) throws Exception;

}
