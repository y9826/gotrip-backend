package com.ytzl.gotrip.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.ytzl.gotrip.model.GotripUser;
import com.ytzl.gotrip.rpc.api.RpcGotripUserService;
import com.ytzl.gotrip.service.GotripUserService;
import com.ytzl.gotrip.utils.common.EmptyUtils;
import com.ytzl.gotrip.utils.common.ErrorCode;
import com.ytzl.gotrip.utils.exception.GotripException;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("gotripUserService")
public class GotripUserServiceImpl implements GotripUserService {


    @Reference
    private RpcGotripUserService rpcGotripUserService;

    @Override
    public GotripUser findByUserCode(String userCode) throws Exception {

        if(EmptyUtils.isEmpty(userCode)){
            throw new GotripException("用户Code不能为空！", ErrorCode.AUTH_PARAMETER_ERROR);
        }

        Map<String,Object> params = new HashMap<>();
        params.put("userCode",userCode);
        List<GotripUser> gotripUserList = rpcGotripUserService.getGotripUserListByMap(params);
        if (EmptyUtils.isEmpty(gotripUserList)) {
            throw new GotripException("登陆账号不存在！", ErrorCode.AUTH_PARAMETER_ERROR);
        }
        return gotripUserList.get(0);
    }
}
